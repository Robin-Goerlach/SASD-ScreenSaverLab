namespace Sasd.ScreenSaverLab.Core;

/// <summary>
/// Represents command-line startup options passed by Windows or by the developer.
/// </summary>
/// <param name="Mode">The requested application mode.</param>
/// <param name="PreviewWindowHandle">The native preview window handle, if Windows supplied one.</param>
public sealed record ScreenSaverStartupOptions(
    ScreenSaverMode Mode,
    nint? PreviewWindowHandle = null)
{
    /// <summary>
    /// Gets default options for a normal fullscreen development run.
    /// </summary>
    public static ScreenSaverStartupOptions Default => new(ScreenSaverMode.Normal);
}
