namespace Sasd.ScreenSaverLab.Core;

/// <summary>
/// Parses the small command-line argument set used by Windows screensavers.
/// </summary>
/// <remarks>
/// Windows commonly starts screensavers with arguments such as /s, /c or /p HWND.
/// V0.1 parses these arguments, but only fullscreen mode is fully implemented.
/// </remarks>
public static class ScreenSaverCommandLineParser
{
    /// <summary>
    /// Parses command-line arguments into a strongly typed options object.
    /// </summary>
    /// <param name="args">Raw command-line arguments.</param>
    /// <returns>Parsed startup options.</returns>
    public static ScreenSaverStartupOptions Parse(string[] args)
    {
        if (args.Length == 0)
        {
            return ScreenSaverStartupOptions.Default;
        }

        string first = NormalizeArgument(args[0]);

        if (first == "s")
        {
            return new ScreenSaverStartupOptions(ScreenSaverMode.Fullscreen);
        }

        if (first == "c")
        {
            return new ScreenSaverStartupOptions(ScreenSaverMode.Configure);
        }

        if (first == "p")
        {
            nint? previewHandle = null;

            if (args.Length > 1 && nint.TryParse(args[1], out nint handle))
            {
                previewHandle = handle;
            }

            return new ScreenSaverStartupOptions(ScreenSaverMode.Preview, previewHandle);
        }

        return ScreenSaverStartupOptions.Default;
    }

    /// <summary>
    /// Normalizes arguments so /s, -s and s can be handled uniformly.
    /// </summary>
    private static string NormalizeArgument(string argument)
    {
        return argument
            .Trim()
            .TrimStart('/', '-')
            .ToLowerInvariant();
    }
}
