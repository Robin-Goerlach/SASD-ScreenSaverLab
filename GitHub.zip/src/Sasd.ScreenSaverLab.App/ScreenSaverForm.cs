using System.Diagnostics;
using System.Drawing.Drawing2D;
using Sasd.ScreenSaverLab.Core;

namespace Sasd.ScreenSaverLab.App;

/// <summary>
/// Main fullscreen host form for all screensaver effects.
/// </summary>
/// <remarks>
/// The form deliberately contains only host behavior: fullscreen setup, input handling,
/// update timing, painting, and a small clock overlay. The visual effect itself is
/// delegated to <see cref="IScreenSaverEffect" />.
/// </remarks>
public sealed class ScreenSaverForm : Form
{
    private const int TargetFrameIntervalMs = 16;
    private const int MouseExitThresholdPixels = 12;

    private readonly IScreenSaverEffect _effect;
    private readonly IEffectClock _clock;
    private readonly System.Windows.Forms.Timer _timer;
    private readonly Stopwatch _stopwatch = new();

    private Point? _initialMousePosition;
    private bool _isInitialized;

    /// <summary>
    /// Initializes a new screensaver host form.
    /// </summary>
    /// <param name="effect">The visual effect rendered by this host.</param>
    /// <param name="clock">Clock abstraction used by the overlay.</param>
    public ScreenSaverForm(IScreenSaverEffect effect, IEffectClock clock)
    {
        _effect = effect ?? throw new ArgumentNullException(nameof(effect));
        _clock = clock ?? throw new ArgumentNullException(nameof(clock));

        _timer = new System.Windows.Forms.Timer
        {
            Interval = TargetFrameIntervalMs
        };

        _timer.Tick += Timer_Tick;

        ConfigureWindow();
        ConfigureRendering();
    }

    /// <summary>
    /// Configures the form so it behaves like a fullscreen screensaver window.
    /// </summary>
    private void ConfigureWindow()
    {
        Text = "SASD ScreenSaver Lab";
        FormBorderStyle = FormBorderStyle.None;
        WindowState = FormWindowState.Maximized;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        KeyPreview = true;
        BackColor = Color.Black;
    }

    /// <summary>
    /// Enables double buffering and redraw behavior for smoother animation.
    /// </summary>
    private void ConfigureRendering()
    {
        SetStyle(
            ControlStyles.AllPaintingInWmPaint |
            ControlStyles.UserPaint |
            ControlStyles.OptimizedDoubleBuffer |
            ControlStyles.ResizeRedraw,
            true);

        UpdateStyles();
    }

    /// <inheritdoc />
    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);

        Cursor.Hide();
        _initialMousePosition = Cursor.Position;

        _effect.Initialize(ClientSize);

        _stopwatch.Restart();
        _timer.Start();
        _isInitialized = true;
    }

    /// <inheritdoc />
    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _timer.Stop();
        _timer.Tick -= Timer_Tick;
        _timer.Dispose();

        Cursor.Show();
        base.OnFormClosed(e);
    }

    /// <inheritdoc />
    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);

        if (_isInitialized)
        {
            // Reinitialize the effect after a resize. This keeps V0.1 simple and avoids
            // partially off-screen particles after monitor or window size changes.
            _effect.Initialize(ClientSize);
        }
    }

    /// <inheritdoc />
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

        _effect.Render(e.Graphics, ClientSize);
        DrawOverlay(e.Graphics);
    }

    /// <inheritdoc />
    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        Close();
    }

    /// <inheritdoc />
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        Close();
    }

    /// <inheritdoc />
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);

        if (!_isInitialized || _initialMousePosition is null)
        {
            return;
        }

        Point current = Cursor.Position;
        Point initial = _initialMousePosition.Value;

        int dx = current.X - initial.X;
        int dy = current.Y - initial.Y;
        double distance = Math.Sqrt(dx * dx + dy * dy);

        if (distance >= MouseExitThresholdPixels)
        {
            Close();
        }
    }

    /// <summary>
    /// Updates the active effect and schedules the next repaint.
    /// </summary>
    private void Timer_Tick(object? sender, EventArgs e)
    {
        TimeSpan elapsed = _stopwatch.Elapsed;
        _stopwatch.Restart();

        _effect.Update(elapsed, ClientSize);
        Invalidate();
    }

    /// <summary>
    /// Draws small informational overlay text. This can become configurable later.
    /// </summary>
    private void DrawOverlay(Graphics graphics)
    {
        DateTime now = _clock.Now;

        string timeText = now.ToString("HH:mm");
        string dateText = now.ToString("dddd, dd. MMMM yyyy");
        string effectText = _effect.Name;

        using Font timeFont = new("Segoe UI", 36f, FontStyle.Regular, GraphicsUnit.Point);
        using Font dateFont = new("Segoe UI", 11f, FontStyle.Regular, GraphicsUnit.Point);
        using Font effectFont = new("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point);

        using SolidBrush timeBrush = new(Color.FromArgb(220, 235, 245, 255));
        using SolidBrush secondaryBrush = new(Color.FromArgb(145, 210, 225, 240));

        SizeF timeSize = graphics.MeasureString(timeText, timeFont);
        SizeF dateSize = graphics.MeasureString(dateText, dateFont);
        SizeF effectSize = graphics.MeasureString(effectText, effectFont);

        float margin = 32f;
        float x = ClientSize.Width - Math.Max(timeSize.Width, dateSize.Width) - margin;
        float y = ClientSize.Height - timeSize.Height - dateSize.Height - effectSize.Height - margin;

        graphics.DrawString(effectText, effectFont, secondaryBrush, x, y);
        graphics.DrawString(timeText, timeFont, timeBrush, x, y + effectSize.Height + 2);
        graphics.DrawString(dateText, dateFont, secondaryBrush, x, y + effectSize.Height + timeSize.Height + 4);
    }
}
