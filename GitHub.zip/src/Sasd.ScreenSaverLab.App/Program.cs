using Sasd.ScreenSaverLab.App;
using Sasd.ScreenSaverLab.Core;
using Sasd.ScreenSaverLab.Effects;

namespace Sasd.ScreenSaverLab.App;

internal static class Program
{
    /// <summary>
    /// Application entry point.
    /// </summary>
    [STAThread]
    private static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();

        ScreenSaverStartupOptions options = ScreenSaverCommandLineParser.Parse(args);

        if (options.Mode == ScreenSaverMode.Configure)
        {
            MessageBox.Show(
                "SASD ScreenSaver Lab V0.1\n\nA configuration dialog will be added in a later version.",
                "SASD ScreenSaver Lab",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        if (options.Mode == ScreenSaverMode.Preview)
        {
            MessageBox.Show(
                "Preview mode is parsed but not implemented yet.\n\nPlease run the application normally for the V0.1 prototype.",
                "SASD ScreenSaver Lab",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        // V0.1 starts with one built-in effect. Later this can come from a small
        // effect catalog and eventually from configuration.
        var effect = new StarDriftEffect();

        Application.Run(new ScreenSaverForm(effect, new SystemEffectClock()));
    }
}
