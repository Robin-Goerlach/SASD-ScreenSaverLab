# SASD ScreenSaver Lab

**SASD ScreenSaver Lab** is a small experimental Windows desktop project for creating original screensaver and visualizer effects.

The goal is not to copy existing Apple, iTunes, After Dark, or other historic screensavers one-to-one. Instead, this project uses the general idea of animated visual effects as inspiration and builds its own SASD-style effects, names, palettes, and implementation.

## Current status

Version: **V0.1 prototype**

Implemented:

- A small Windows Forms host application
- A modular effect interface
- First effect: `StarDriftEffect`
- Fullscreen mode
- Basic render loop
- Exit on keyboard, mouse button, or noticeable mouse movement
- Simple clock overlay
- Initial project documentation

Not yet implemented:

- Real `.scr` packaging
- Configuration dialog
- Windows preview mode for the screensaver settings panel
- Multiple selectable effects
- Audio-reactive visualizer mode
- Plugin loading from external assemblies

## Intended technology stack

- C#
- .NET 8
- Windows Forms
- Later possibly SkiaSharp, WPF, OpenTK, Silk.NET, or WebView2 depending on the visual direction

## Project structure

```text
SASD-ScreenSaverLab/
  README.md
  LICENSE
  docs/
    010_Project_Concept.md
    020_Roadmap.md
    030_Technical_Design.md
    040_Effect_Ideas.md
  src/
    Sasd.ScreenSaverLab.App/
    Sasd.ScreenSaverLab.Core/
    Sasd.ScreenSaverLab.Effects/
```

## Build and run

Open `Sasd.ScreenSaverLab.sln` in Visual Studio 2022.

Recommended startup project:

```text
src/Sasd.ScreenSaverLab.App/Sasd.ScreenSaverLab.App.csproj
```

Or run from the command line on Windows with the .NET SDK installed:

```powershell
dotnet run --project src/Sasd.ScreenSaverLab.App/Sasd.ScreenSaverLab.App.csproj
```

The application currently starts in fullscreen mode. Press **Esc**, click the mouse, or move the mouse noticeably to close it.

## Design principle

V0.1 deliberately avoids a heavy plugin architecture. Effects are modular inside the solution, but external plugin loading is postponed until there are several real effects and a clearer need for it.

This keeps the first version small, understandable, and robust.
